const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Registro = require('./models/Registro');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Conectarse a MongoDB
mongoose.connect('mongodb://localhost:27017/miapp', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(async () => {
    console.log("Conectado a la base de datos MongoDB");

    // Añadir registros iniciales siempre
    const registrosIniciales = [
        { nombre: 'Registro 1', descripcion: 'Descripción del registro 1' },
        { nombre: 'Registro 2', descripcion: 'Descripción del registro 2' },
        { nombre: 'Registro 3', descripcion: 'Descripción del registro 3' },
        { nombre: 'Registro 4', descripcion: 'Descripción del registro 4' },
        { nombre: 'Registro 5', descripcion: 'Descripción del registro 5' }
    ];

    // Insertar registros iniciales en la base de datos
    for (const registro of registrosIniciales) {
        await Registro.findOneAndUpdate(
            { nombre: registro.nombre }, // Busca por el nombre
            registro,                   // Actualiza o inserta el registro
            { upsert: true }           // Inserta si no existe
        );
    }

    console.log('Registros iniciales asegurados en la base de datos.');
})
.catch(err => {
    console.error("Error al conectar a la base de datos:", err);
});

// Rutas
app.get('/', async (req, res) => {
    try {
        const registros = await Registro.find();
        res.render('index', { registros });
    } catch (error) {
        console.error('Error al obtener los registros:', error);
        res.status(500).send('Error al obtener los registros');
    }
});

// Ruta para mostrar todos los registros
app.get('/mostrar-todos', async (req, res) => {
    try {
        const registros = await Registro.find();
        res.render('mostrar-todos', { registros }); // Renderiza la vista para mostrar todos los registros
    } catch (error) {
        console.error('Error al obtener todos los registros:', error);
        res.status(500).send('Error al obtener todos los registros');
    }
});

app.get('/crear', (req, res) => {
    res.render('create');
});

// Crear un nuevo registro
app.post('/crear', async (req, res) => {
    try {
        const nuevoRegistro = new Registro(req.body);
        await nuevoRegistro.save();
        console.log('Nuevo registro creado:', nuevoRegistro);
        res.redirect('/');
    } catch (error) {
        console.error('Error al crear el registro:', error);
        res.status(500).send('Error al crear el registro');
    }
});

// Editar un registro
app.get('/editar/:id', async (req, res) => {
    try {
        const registro = await Registro.findById(req.params.id);
        if (!registro) {
            return res.status(404).send('Registro no encontrado');
        }
        res.render('edit', { registro });
    } catch (error) {
        console.error('Error al obtener el registro:', error);
        res.status(500).send('Error al obtener el registro');
    }
});

// Actualizar un registro
app.post('/editar/:id', async (req, res) => {
    try {
        await Registro.findByIdAndUpdate(req.params.id, req.body);
        console.log('Registro actualizado:', req.params.id);
        res.redirect('/');
    } catch (error) {
        console.error('Error al actualizar el registro:', error);
        res.status(500).send('Error al actualizar el registro');
    }
});

// Eliminar un registro
app.post('/eliminar/:id', async (req, res) => {
    try {
        await Registro.findByIdAndDelete(req.params.id);
        console.log('Registro eliminado:', req.params.id);
        res.redirect('/');
    } catch (error) {
        console.error('Error al eliminar el registro:', error);
        res.status(500).send('Error al eliminar el registro');
    }
});

// Buscar por letra inicial
app.get('/buscar', async (req, res) => {
    const letraInicial = req.query.letra || '';
    
    try {
        const registros = await Registro.find({ nombre: { $regex: `^${letraInicial}`, $options: 'i' } });
        res.render('index', { registros, letraInicial });
    } catch (error) {
        console.error('Error al buscar los registros:', error);
        res.status(500).send('Error al buscar los registros');
    }
});

// Ruta adicional para verificar los registros en formato JSON
app.get('/ver-registros', async (req, res) => {
    try {
        const registros = await Registro.find();
        console.log('Registros en la base de datos:', registros);
        res.json(registros);
    } catch (error) {
        console.error('Error al obtener los registros:', error);
        res.status(500).send('Error al obtener los registros');
    }
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});